Welcome to Linkbook
----------------------

Store & Categorize 
your favourite links
in just a few clicks.

Open "index.html" with
any web browser.
No internet connection 
required.

Tools used:
1.HTML
2.CSS
3.Javascript

Developers:
1.Vishal Thakur
2.Ravi Rahul

References:
1.stackOverflow.com
2.Brad Traversy-
  javascript tutorial
3.w3schools.com