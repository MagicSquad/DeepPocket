function fetchBookmarks(){
  // Get bookmarks from localStorage
  var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
  // Get output id
  var bookmarksResults = document.getElementById('bookmarksResults');

  // Build output
  bookmarksResults.innerHTML = '';
  for(var i = 0; i < bookmarks.length; i++){
    var name = bookmarks[i].name;
    var url = bookmarks[i].url;

    bookmarksResults.innerHTML += '<div class="well">'+
                                  '<h3>'+name+
                                  ' <a class="btn btn-default" target="_blank" href="'+url+'">Visit</a> ' +
                                  ' <a onclick="deleteBookmark(\''+url+'\')" class="btn btn-danger" href="#">Delete</a> ' +
                        ' <a id="mvc" class="btn btn-default" onclick="marklink(\''+i+'\')">Move to new category</a> '+
                                  '</h3>'+
                                  '</div>';
  }
    var bmr=bookmarksResults;
    var categorys=JSON.parse(localStorage.getItem("categorys"));
    for(var i=0;i<categorys.length;i++){
        bmr.innerHTML+='<h3 onclick="moveToCat('+i+')">Category:'+categorys[i].cName+'</h3>';
        var List=JSON.parse(localStorage.getItem('list'+i));
        if(List==null){
            continue;
        }
        for(var j=0;j<List.length;j++){
            var z=List[j];
            if(bookmarks[z]==null){
                continue;
            }
            var name = bookmarks[z].name;
    var url = bookmarks[z].url;

    bookmarksResults.innerHTML += '<div class="well">'+
                                  '<h3>'+name+
                                  ' <a class="btn btn-default" target="_blank" href="'+url+'">Visit</a> ' +
                                  ' <a onclick="deleteBookmark(\''+url+'\')" class="btn btn-danger" href="#">Delete</a> ' +
                        ' <a id="mvc" class="btn btn-default" onclick="marklink(\''+z+'\')">Move to new category</a> '+
                                  '</h3>'+
                                  '</div>';
        }
    }
}
function marklink(l){//l:link number
    localStorage.setItem('l',JSON.stringify(l));
}
function validateForm(siteName, siteUrl){
  if(!siteName || !siteUrl){
    alert('Please fill in the form');
    return false;
  }

  var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
  var regex = new RegExp(expression);

  if(!siteUrl.match(regex)){
    alert('Please use a valid URL');
    return false;
  }

  return true;
}

document.getElementById("submitbutton").addEventListener("click", saveBookmark);
function saveBookmark(e){
  // Get form values
  var siteName =document.getElementById('siteName').value;
  var siteUrl =document.getElementById('siteUrl').value;

  if(!validateForm(siteName, siteUrl)){
    return false;
  }

  var bookmark = {
    name: siteName,
    url: siteUrl
  }
  // Test if bookmarks is null
  if(localStorage.getItem('bookmarks') === null){
    // Init array
    var bookmarks = [];
    // Add to array
    bookmarks.push(bookmark);
    // Set to localStorage
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    } 
   else {
    // Get bookmarks from localStorage
    var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
    var found=0;
    for(var i=0; i < bookmarks.length ; i++){
        if(bookmarks[i].url==bookmark.url){
            found=1;
            alert("already present!");
            document.getElementById('myForm').reset();
            return;
        }
    }
    
    // Add bookmark to array
    bookmarks.push(bookmark);
    // Re-set back to localStorage
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    
  }

  // Clear form
  document.getElementById('myForm').reset();

  // Re-fetch bookmarks
  fetchBookmarks();

  // Prevent form from submitting
  e.preventDefault();
}

document.getElementById("createnewcat").addEventListener("click", savecategory);
function savecategory(e){
  // Get form values
  var catname =document.getElementById('newcatname').value;
  if(catname=="clear"){
      window.localStorage.clear();
      document.getElementById("myForm").reset();
      fetchBookmarks();
      e.preventDefault();
      return;
  }
  if(catname==""){
      alert("Category name empty!");
      document.getElementById("myForm").reset();
      fetchBookmarks();
      e.preventDefault();
      return;
  }
  var category = {
    cName: catname
  }
  // Test if categorys is null
  if(localStorage.getItem('categorys') === null){
    // Init array
    var categorys = [];
    // Add to array
    categorys.push(category);
    // Set to localStorage
    localStorage.setItem('categorys', JSON.stringify(categorys));
    //localStorage.setItem('categorys',categorys);
    } 
   else {
    // Get categorys from localStorage
    var categorys = JSON.parse(localStorage.getItem('categorys'));
    //var categorys=localStorage.getItem('categorys');
    for(var i=0; i < categorys.length ; i++){
        if(categorys[i].cName==catname){
            alert("already present!");
            document.getElementById('myForm').reset();
            fetchBookmarks();
            e.preventDefault();
            return;
        }
    }
    
    // Add category to array
    categorys.push(category);
    // Re-set back to localStorage
    localStorage.setItem('categorys', JSON.stringify(categorys));
    //localStorage.setItem('categorys',categorys);
       //location.reload();
  }

  // Clear form
  document.getElementById('myForm').reset();
    location.reload();
  // Re-fetch bookmarks
  fetchbookmarks();
    
  // Prevent form from submitting
  e.preventDefault();
}

function deleteBookmark(url){
  // Get bookmarks from localStorage
  var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
  // Loop throught bookmarks
  for(var i =0;i < bookmarks.length;i++){
    if(bookmarks[i].url == url){
      // Remove from array
      bookmarks.splice(i, 1);
    }
  }
  // Re-set back to localStorage
  localStorage.setItem('bookmarks', JSON.stringify(bookmarks));

  // Re-fetch bookmarks
  fetchBookmarks();
}

function moveToCat(i){
    //add link to new category
    var l=JSON.parse(localStorage.getItem('l'));
    //bookmarks[l] is to be moved to 'list-listnum';
    if(l==null || l=="-1"){
        return;
    }
    if(JSON.parse(localStorage.getItem('list'+i))===null){
        var List=[];
        List.push(l);
        localStorage.setItem('list'+i,JSON.stringify(List));
    }
    else{
        var List=JSON.parse(localStorage.getItem('list'+i));
        List.push(l);
        localStorage.setItem('list'+i,JSON.stringify(List));
    }
    l=-1;
    localStorage.setItem('l',JSON.stringify(l));
    fetchBookmarks();
}



