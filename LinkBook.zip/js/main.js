// Listen for form submit
document.getElementById("submitbutton").addEventListener("click", saveBookmark);
var catval=0;
// Save Bookmark
function saveBookmark(e){
  // Get form values
  var siteName =document.getElementById('siteName').value;
  var siteUrl =document.getElementById('siteUrl').value;

  if(!validateForm(siteName, siteUrl)){
    return false;
  }

  var bookmark = {
    name: siteName,
    url: siteUrl
  }
  // Test if bookmarks is null
  if(localStorage.getItem('bookmarks') == null){
    // Init array
    var bookmarks = [];
    // Add to array
    bookmarks.push(bookmark);
    // Set to localStorage
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    } 
   else {
    // Get bookmarks from localStorage
    var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
    var found=0;
    for(var i=0; i < bookmarks.length ; i++){
        if(bookmarks[i].url==bookmark.url){
            found=1;
            alert("already present!");
            document.getElementById('myForm').reset();
            return;
        }
    }
    
    // Add bookmark to array
    bookmarks.push(bookmark);
    // Re-set back to localStorage
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    
  }

  // Clear form
  document.getElementById('myForm').reset();

  // Re-fetch bookmarks
  fetchBookmarks();

  // Prevent form from submitting
  e.preventDefault();
}
//create new category
document.getElementById("createnewcat").addEventListener("click", savecategory);

// Save category
function savecategory(e){
  // Get form values
  var catname =document.getElementById('catname').value;
  var category = {
    name: catname
  }
  // Test if categorys is null
  if(localStorage.getItem('categorys') == null){
    // Init array
    var categorys = [];
    // Add to array
    categorys.push(category);
    // Set to localStorage
    localStorage.setItem('categorys', JSON.stringify(categorys));
    } 
   else {
    // Get categorys from localStorage
    var categorys = JSON.parse(localStorage.getItem('categorys'));
    var found=0;
    for(var i=0; i < categorys.length ; i++){
        if(categorys[i].name==catname){
            found=1;
            alert("already present!");
            document.getElementById('myForm').reset();
            return;
        }
    }
    
    // Add category to array
    categorys.push(category);
    // Re-set back to localStorage
    localStorage.setItem('categorys', JSON.stringify(categorys));
    alert(categorys.length);
  }

  // Clear form
  document.getElementById('myForm').reset();

  // Re-fetch bookmarks
  fetchbookmarks();

  // Prevent form from submitting
  e.preventDefault();
}

// Delete bookmarka
function deleteBookmark(url){
  // Get bookmarks from localStorage
  var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
  // Loop throught bookmarks
  for(var i =0;i < bookmarks.length;i++){
    if(bookmarks[i].url == url){
      // Remove from array
      bookmarks.splice(i, 1);
    }
  }
  // Re-set back to localStorage
  localStorage.setItem('bookmarks', JSON.stringify(bookmarks));

  // Re-fetch bookmarks
  //fetchBookmarks();
}
//move link
function movelink(url){
    alert("trying to move link!");
    //add link to new category
}

// Fetch bookmarks
function fetchBookmarks(){
  // Get bookmarks from localStorage
  var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
  // Get output id
  var bookmarksResults = document.getElementById('bookmarksResults');

  // Build output
  bookmarksResults.innerHTML = '';
  for(var i = 0; i < bookmarks.length; i++){
    var name = bookmarks[i].name;
    var url = bookmarks[i].url;

    bookmarksResults.innerHTML += '<div class="well">'+
                                  '<h3>'+name+
                                  ' <a class="btn btn-default" target="_blank" href="'+url+'">Visit</a> ' +
                                  ' <a onclick="deleteBookmark(\''+url+'\')" class="btn btn-danger" href="#">Delete</a> ' +
                        ' <a id="mvc" class="btn btn-default" onclick="movelink(\''+url+'\')">Move to new category</a> '+
                                  '</h3>'+
                                  '</div>';
  }
    var bm=bookmarksResults;
    var categorys=JSON.parse(localStorage.getItem('categorys'));
    for(var i=0;i<categorys.length;i++){
        bm.innerHTML+='<h2>'+categorys[i].name+'</h2>'+
            '<button class="btn btn-default">Delete Link</button>';
        
    }
}

// Validate Form
function validateForm(siteName, siteUrl){
  if(!siteName || !siteUrl){
    alert('Please fill in the form');
    return false;
  }

  var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
  var regex = new RegExp(expression);

  if(!siteUrl.match(regex)){
    alert('Please use a valid URL');
    return false;
  }

  return true;
}
